CREATE DATABASE travel_booking;

USE travel_booking;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(255) NOT NULL
);

CREATE TABLE tickets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    destination VARCHAR(100),
    departure_date DATE,
    price DECIMAL(10, 2)
);

INSERT INTO users (username, password) VALUES ('admin', MD5('password'));