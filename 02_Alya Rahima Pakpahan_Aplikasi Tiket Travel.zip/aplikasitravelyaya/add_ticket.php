<?php
include('../includes/config.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $destination = $_POST['destination'];
    $departure_date = $_POST['departure_date'];
    $price = $_POST['price'];

    $sql = "INSERT INTO tickets (destination, departure_date, price) VALUES (?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssd", $destination, $departure_date, $price);

    if ($stmt->execute()) {
        echo "Ticket added successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}
?>